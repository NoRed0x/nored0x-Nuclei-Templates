# nuclei-fuzzer-templates

My personal collection of nuclei templates.

## Credits

Special thanks to [fopwn](https://github.com/notnci) for providing me suggestions.

## References

- [Fuzzing Templates](https://github.com/projectdiscovery/fuzzing-templates)
